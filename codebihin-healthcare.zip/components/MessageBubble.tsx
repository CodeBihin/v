
import React from 'react';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';

  // Simple Markdown parsing for code blocks and bold text
  const renderContent = (content: string) => {
    return content.split(/(\`\`\`[\s\S]*?\`\`\`|\*\*.*?\*\*)/g).map((part, i) => {
      if (part.startsWith('```')) {
        const code = part.replace(/\`\`\`/g, '').trim();
        return (
          <pre key={i} className="bg-zinc-950 p-4 rounded-lg my-3 overflow-x-auto border border-zinc-800 font-mono text-sm leading-relaxed">
            <code>{code}</code>
          </pre>
        );
      }
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i}>{part.slice(2, -2)}</strong>;
      }
      return <span key={i} className="whitespace-pre-wrap">{part}</span>;
    });
  };

  return (
    <div className={`flex w-full mb-8 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex gap-4 max-w-[85%] md:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold ${
          isUser 
            ? 'bg-zinc-700 text-zinc-100' 
            : 'bg-gradient-to-tr from-blue-600 to-indigo-600 text-white'
        }`}>
          {isUser ? 'U' : 'AI'}
        </div>
        <div className="flex flex-col gap-2 overflow-hidden">
          <div className={`px-4 py-3 rounded-2xl text-base leading-relaxed ${
            isUser 
              ? 'bg-zinc-800 text-zinc-100 rounded-tr-none' 
              : 'bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-tl-none'
          }`}>
            {message.image && (
              <img src={message.image} alt="Uploaded" className="max-w-xs rounded-lg mb-3 border border-zinc-700 shadow-lg" />
            )}
            <div>
              {renderContent(message.content)}
              {message.isStreaming && (
                <span className="inline-block w-2 h-4 bg-zinc-500 ml-1 animate-pulse align-middle" />
              )}
            </div>
          </div>
          
          {message.groundingSources && message.groundingSources.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              <span className="text-xs font-medium text-zinc-500 w-full mb-1">Sources:</span>
              {message.groundingSources.map((source, idx) => (
                source.web && (
                  <a
                    key={idx}
                    href={source.web.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-2 py-1 bg-zinc-800/50 border border-zinc-700 rounded-md text-[10px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 transition-colors"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    {source.web.title || source.web.uri}
                  </a>
                )
              ))}
            </div>
          )}
          
          <span className="text-[10px] text-zinc-600 px-1 font-medium">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
