
import React, { useState, useRef, useEffect } from 'react';
import { generateStreamingResponse } from './services/geminiService';
import { Message, ChatThread, GroundingChunk } from './types';
import Sidebar from './components/Sidebar';
import MessageBubble from './components/MessageBubble';

const App: React.FC = () => {
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string>('');
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Modal States
  const [isBuildingPopupOpen, setIsBuildingPopupOpen] = useState(true);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  const [isVerifyInfoOpen, setIsVerifyInfoOpen] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);
  
  // Testimonial Slider State
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeThread = threads.find(t => t.id === activeThreadId);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeThread?.messages]);

  // Handle creating a new chat thread
  const handleNewChat = () => {
    const newThread: ChatThread = {
      id: Date.now().toString(),
      title: 'New Health Consult',
      messages: [],
      updatedAt: Date.now(),
    };
    setThreads([newThread, ...threads]);
    setActiveThreadId(newThread.id);
  };

  // Handle selecting an existing chat thread
  const handleSelectThread = (id: string) => {
    setActiveThreadId(id);
  };

  // Handle deleting a chat thread
  const handleDeleteThread = (id: string) => {
    const newThreads = threads.filter(t => t.id !== id);
    setThreads(newThreads);
    if (activeThreadId === id) {
      setActiveThreadId(newThreads.length > 0 ? newThreads[0].id : '');
    }
  };

  // Handle sending a message
  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    let currentThreadId = activeThreadId;
    
    // If no active thread, create one
    if (!currentThreadId) {
      const newThreadId = Date.now().toString();
      const newThread: ChatThread = {
        id: newThreadId,
        title: input.slice(0, 30) + (input.length > 30 ? '...' : ''),
        messages: [],
        updatedAt: Date.now(),
      };
      setThreads([newThread, ...threads]);
      setActiveThreadId(newThreadId);
      currentThreadId = newThreadId;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
    };

    // Update state with user message
    setThreads(prev => prev.map(t => 
      t.id === currentThreadId 
        ? { ...t, messages: [...t.messages, userMessage], updatedAt: Date.now() }
        : t
    ));
    
    const prompt = input;
    setInput('');
    setIsTyping(true);

    const assistantMessageId = (Date.now() + 1).toString();
    const assistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    // Add placeholder assistant message for streaming
    setThreads(prev => prev.map(t => 
      t.id === currentThreadId 
        ? { ...t, messages: [...t.messages, assistantMessage] }
        : t
    ));

    const currentThread = threads.find(t => t.id === currentThreadId);
    const history = currentThread ? currentThread.messages : [];

    // Call Gemini Service
    await generateStreamingResponse(
      prompt,
      history,
      (chunk) => {
        setThreads(prev => prev.map(t => 
          t.id === currentThreadId 
            ? {
                ...t,
                messages: t.messages.map(m => 
                  m.id === assistantMessageId 
                    ? { ...m, content: m.content + chunk }
                    : m
                )
              }
            : t
        ));
      },
      (fullText, sources) => {
        setThreads(prev => prev.map(t => 
          t.id === currentThreadId 
            ? {
                ...t,
                messages: t.messages.map(m => 
                  m.id === assistantMessageId 
                    ? { ...m, content: fullText, isStreaming: false, groundingSources: sources }
                    : m
                ),
                // Update title if it's the first exchange
                title: t.messages.length <= 2 ? prompt.slice(0, 30) + (prompt.length > 30 ? '...' : '') : t.title
              }
            : t
        ));
        setIsTyping(false);
      }
    );
  };

  // Fixed: Added return statement to satisfy React.FC type requirements
  return (
    <div className="flex h-screen bg-[#09090b] text-zinc-100 overflow-hidden font-sans">
      <Sidebar 
        threads={threads}
        activeThreadId={activeThreadId}
        onSelectThread={handleSelectThread}
        onNewChat={handleNewChat}
        onDeleteThread={handleDeleteThread}
      />
      
      <main className="flex-1 flex flex-col min-0">
        <header className="h-14 border-b border-zinc-800 flex items-center px-4 justify-between bg-[#09090b]/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-900/20">
              CB
            </div>
            <div>
              <h1 className="text-sm font-semibold text-zinc-100">CodeBihin AI Health Mentor</h1>
              <p className="text-[10px] text-zinc-500 font-medium uppercase tracking-widest">Medical Assistance</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold uppercase tracking-wider border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live System
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-8 custom-scrollbar">
          <div className="max-w-3xl mx-auto w-full">
            {activeThread ? (
              activeThread.messages.length > 0 ? (
                activeThread.messages.map(msg => (
                  <MessageBubble key={msg.id} message={msg} />
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center py-20 text-center space-y-8">
                  <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] border border-zinc-800 flex items-center justify-center text-4xl shadow-2xl relative">
                    <div className="absolute inset-0 bg-blue-500/10 blur-2xl rounded-full" />
                    ⚕️
                  </div>
                  <div className="space-y-3">
                    <h2 className="text-3xl font-bold text-white tracking-tight">How can I assist your health today?</h2>
                    <p className="text-zinc-400 max-w-md mx-auto text-lg">Your healthcare guide for Tarakeswar and Champadanga regions.</p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-xl mt-8">
                    {[
                      "Explain symptoms of flu",
                      "Preparation for blood test",
                      "Find doctors in Tarakeswar",
                      "Dietary tips for diabetes"
                    ].map((item) => (
                      <button 
                        key={item}
                        onClick={() => {
                          setInput(item);
                        }}
                        className="p-4 text-left rounded-2xl bg-zinc-900/50 border border-zinc-800 hover:border-zinc-600 hover:bg-zinc-800 transition-all text-sm text-zinc-300 font-medium"
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                </div>
              )
            ) : (
              <div className="h-full flex flex-col items-center justify-center py-20 text-center space-y-6">
                 <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-2xl">
                    💬
                 </div>
                 <h2 className="text-xl font-semibold text-zinc-300">No active conversation</h2>
                 <button 
                  onClick={handleNewChat}
                  className="px-8 py-3 bg-white text-zinc-950 rounded-2xl font-bold hover:bg-zinc-200 transition-all shadow-xl active:scale-95"
                >
                  Start New Session
                </button>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <div className="p-4 md:p-6 border-t border-zinc-800 bg-[#09090b]/95 backdrop-blur-md">
          <div className="max-w-3xl mx-auto relative group">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask me anything about your health..."
              className="w-full bg-zinc-900/80 border border-zinc-800 rounded-3xl px-5 py-4 pr-16 text-base text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all resize-none min-h-[64px] max-h-48 custom-scrollbar shadow-inner"
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className={`absolute right-3 bottom-3 p-3 rounded-2xl transition-all duration-300 ${
                input.trim() && !isTyping 
                  ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg' 
                  : 'bg-zinc-800 text-zinc-500 opacity-50 cursor-not-allowed'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
            </button>
          </div>
          <div className="flex flex-col sm:flex-row justify-between items-center max-w-3xl mx-auto mt-4 px-2 gap-2">
            <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-tighter">
              CodeBihin Health Mentor v1.0 • Verified Medical Knowledge Base
            </p>
            <p className="text-[9px] text-zinc-700 italic">
              Disclaimer: Not a replacement for professional clinical advice.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

// Fixed: Added default export to resolve "Module './App' has no default export"
export default App;
