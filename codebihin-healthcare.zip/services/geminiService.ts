
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message, GroundingChunk } from "../types";

// Always use process.env.API_KEY directly as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Using gemini-3-pro-preview for complex medical reasoning and symptom analysis.
const MODEL_NAME = 'gemini-3-pro-preview';

export const generateStreamingResponse = async (
  prompt: string,
  history: Message[],
  onChunk: (chunk: string) => void,
  onFinished: (fullText: string, sources?: GroundingChunk[]) => void,
  image?: string
) => {
  try {
    const formattedHistory = history.map(msg => ({
      role: msg.role === 'user' ? 'user' as const : 'model' as const,
      parts: [{ text: msg.content }]
    }));

    const contents: any = {
      parts: [
        ...(image ? [{ inlineData: { mimeType: 'image/png', data: image.split(',')[1] } }] : []),
        { text: prompt }
      ]
    };

    const responseStream = await ai.models.generateContentStream({
      model: MODEL_NAME,
      contents: formattedHistory.length > 0 
        ? [...formattedHistory, contents] 
        : contents,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
        topP: 0.95,
        systemInstruction: `You are the AI Health Mentor for CodeBihin, a premier healthcare portal serving Tarakeswar and Champadanga, West Bengal. 
        Your mission is to help users navigate their healthcare journey.
        1. Provide general health tips, explain medical symptoms (with appropriate disclaimers), and suggest preparation for diagnostic tests.
        2. Help users identify the right type of doctor for their symptoms (e.g., "See a cardiologist for chest pain").
        3. Mention that CodeBihin provides a directory of verified doctors in Tarakeswar and Champadanga.
        4. Use a professional, compassionate, and authoritative tone. 
        5. Use Google Search grounding for any medical news or official health announcements in India.
        6. Always emphasize that in emergencies, they must visit a hospital immediately.`
      }
    });

    let fullContent = '';
    let groundingSources: GroundingChunk[] = [];

    for await (const chunk of responseStream) {
      // Accessing text as a property as per guidelines.
      const text = chunk.text || '';
      fullContent += text;
      onChunk(text);
      
      const sources = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (sources && sources.length > 0) {
        groundingSources = sources as GroundingChunk[];
      }
    }

    onFinished(fullContent, groundingSources);
  } catch (error) {
    console.error("Gemini API Error:", error);
    onFinished("CodeBihin Health Assistant is temporarily offline. Please try again or consult a doctor directly.");
  }
};
