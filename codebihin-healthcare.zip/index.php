<?php
/**
 * CodeBihin® - Elite Healthcare Infrastructure
 * West Bengal's Premium Digital Health Portal
 * Version: 6.5.0 (Enterprise Gold Edition)
 * 
 * CORE DESIGN PRINCIPLES:
 * - Professionalism: "We Care For Your Health"
 * - Trust: Verified Medical Stamps & Blue Ticks
 * - Accessibility: Full Mobile Auto-Fit Architecture
 * - SEO: Bot-Aware Popup Logic
 */

session_start();

// --- SEARCH ENGINE BOT DETECTION (For SEO integrity) ---
function isSearchEngineBot() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    $bots = ['googlebot', 'bingbot', 'slurp', 'duckduckbot', 'baiduspider', 'yandexbot', 'sogou', 'exabot', 'facebot', 'ia_archiver'];
    foreach ($bots as $bot) {
        if (strpos($ua, $bot) !== false) return true;
    }
    return false;
}
$isBot = isSearchEngineBot();

// --- USER SESSION HELPERS ---
if (!function_exists('isUserLoggedIn')) {
    function isUserLoggedIn() { return isset($_SESSION['user_id']); }
}

$site_config = [
    'admin_email' => 'admin@codebihin.in',
    'support_email' => 'support@codebihin.in',
    'branding' => 'CodeBihin Verified',
    'theme_line' => 'We Care For Your Health',
    'location_focus' => 'Tarakeswar & Champadanga'
];

// Anti-Copy & DevTools Protection
$security_js = "
<script>
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.onkeydown = function(e) {
        if(e.keyCode == 123 || (e.ctrlKey && e.shiftKey && (e.keyCode == 73 || e.keyCode == 67 || e.keyCode == 74)) || (e.ctrlKey && e.keyCode == 85)) return false;
    };
</script>
<style>
    * { -webkit-user-select: none !important; -moz-user-select: none !important; -ms-user-select: none !important; user-select: none !important; }
    input, textarea, select { user-select: text !important; -webkit-user-select: text !important; }
</style>";

?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    
    <!-- SEO METADATA -->
    <title>CodeBihin | Verified Healthcare Hub Tarakeswar & Champadanga</title>
    <meta name="description" content="Official CodeBihin healthcare portal. Connect with verified medical experts in Tarakeswar & Champadanga. We care for your health with zero patient fees.">
    <meta name="keywords" content="Doctor Booking, Tarakeswar Health, Champadanga Medical, Verified Doctor, CodeBihin, Health West Bengal">
    <link rel="canonical" href="https://codebihin.in/">
    <meta property="og:title" content="CodeBihin Healthcare - Professional & Verified">
    <meta property="og:type" content="website">

    <!-- EXTERNAL ASSETS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root { 
            --cb-blue: #2563eb; 
            --cb-emerald: #10b981; 
            --cb-dark: #0f172a;
            --cb-slate: #64748b;
        }
        
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: var(--cb-dark); 
            overflow-x: hidden; 
            -webkit-tap-highlight-color: transparent;
            background-color: #ffffff;
        }

        .medical-gradient { 
            background: linear-gradient(135deg, #f8fafc 0%, #eff6ff 50%, #f0fdf4 100%); 
        }

        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        
        /* Interactive Blue Tick */
        .blue-tick-verify {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            width: 20px; height: 20px; border-radius: 50%;
            display: inline-flex; align-items: center; justify-content: center;
            color: white; font-size: 10px; cursor: pointer;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 2px solid white; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
            margin-left: 8px; vertical-align: middle;
        }
        .blue-tick-verify:hover { transform: scale(1.35) rotate(15deg); box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4); }

        /* Premium Digital Stamp */
        .cb-verified-stamp {
            display: inline-block; padding: 10px 22px; 
            border: 3px double var(--cb-blue);
            color: var(--cb-blue); font-weight: 800; 
            text-transform: uppercase; border-radius: 12px;
            transform: rotate(-2deg); background: rgba(37, 99, 235, 0.04); 
            font-size: 11px; letter-spacing: 0.12em; 
            pointer-events: none; opacity: 0;
        }
        .reveal-stamp { animation: stampIn 0.9s cubic-bezier(0.23, 1, 0.32, 1) forwards; }
        @keyframes stampIn { from { transform: scale(2.5) rotate(-25deg); opacity: 0; } to { transform: scale(1) rotate(-2deg); opacity: 1; } }

        /* Testimonial Slider System */
        .cb-slider { display: flex; overflow-x: auto; scroll-snap-type: x mandatory; scroll-behavior: smooth; -ms-overflow-style: none; scrollbar-width: none; }
        .cb-slider::-webkit-scrollbar { display: none; }
        .cb-slide { flex: 0 0 100%; scroll-snap-align: center; }
        @media (min-width: 768px) { .cb-slide { flex: 0 0 33.333%; } }

        /* Back to Top Feature */
        #bttBtn {
            position: fixed; bottom: 30px; right: 30px; z-index: 2000;
            background: var(--cb-blue); color: white; border: none; outline: none;
            width: 55px; height: 55px; border-radius: 18px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 15px 35px rgba(37, 99, 235, 0.35);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0; visibility: hidden; transform: translateY(20px);
        }
        #bttBtn.active { opacity: 1; visibility: visible; transform: translateY(0); }
        #bttBtn:hover { transform: translateY(-8px); background: #1d4ed8; }

        /* Mobile Layout Optimization (Fixed Auto-Fit) */
        @media (max-width: 768px) {
            .hero-title { font-size: 2.8rem !important; line-height: 1.1 !important; }
            .doc-grid { grid-template-columns: 1fr !important; gap: 1.5rem !important; }
            .doc-card { padding: 1.5rem !important; border-radius: 40px !important; }
            .doc-header-mobile { flex-direction: column !important; align-items: center !important; text-align: center; }
            .doc-avatar-mobile { margin-bottom: 1.5rem !important; width: 100px !important; height: 100px !important; }
            .modal-content-full { padding: 1.5rem !important; border-radius: 0 !important; height: 100% !important; }
        }

        /* Glassmorphism Components */
        .glass-card { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.3); }
        .section-curve { border-radius: 80px 80px 0 0; }
        
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-12px); } }
        .animate-float { animation: float 6s ease-in-out infinite; }
        
        @keyframes slideInUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
        .reveal-up { opacity: 0; animation: slideInUp 0.8s ease-out forwards; }
    </style>
    <?php echo $security_js; ?>
</head>
<body class="custom-scrollbar">

    <!-- SEARCH CONSOLE SAFE POPUP (Bot-Aware) -->
    <?php if (!$isBot): ?>
    <div id="buildingOverlay" class="fixed inset-0 z-[10000] flex items-center justify-center p-6 bg-slate-900/95 backdrop-blur-2xl">
        <div class="bg-white rounded-[50px] p-10 md:p-16 max-w-lg w-full text-center shadow-3xl reveal-up">
            <div class="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-8 animate-bounce">
                <i class="fas fa-hard-hat"></i>
            </div>
            <h2 class="text-3xl font-black text-slate-900 mb-4 tracking-tighter uppercase">Building Process</h2>
            <p class="text-slate-500 font-bold uppercase text-[11px] tracking-[0.25em] leading-relaxed mb-10">
                This website is under building process so wait until launch thank you
            </p>
            <button onclick="closeBuildingOverlay()" class="w-full py-5 rounded-3xl bg-blue-600 text-white font-black text-xs uppercase tracking-[0.3em] shadow-2xl hover:bg-blue-700 active:scale-95 transition-all">Understood</button>
        </div>
    </div>
    <?php endif; ?>

    <!-- BACK TO TOP -->
    <button id="bttBtn" onclick="scrollToTop()"><i class="fas fa-arrow-up text-xl"></i></button>

    <!-- VERIFICATION INFO MODAL (Triggered by Blue Tick) -->
    <div id="verifyModal" class="hidden fixed inset-0 z-[5000] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-6">
        <div class="bg-white rounded-[50px] p-10 md:p-16 max-w-lg w-full relative shadow-3xl text-center reveal-up">
            <button onclick="toggleModal('verifyModal', false)" class="absolute top-10 right-10 text-slate-400 hover:text-slate-900"><i class="fas fa-times text-2xl"></i></button>
            <div class="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center text-4xl mx-auto mb-8 shadow-inner"><i class="fas fa-user-check"></i></div>
            <h3 class="text-2xl font-black text-slate-900 mb-4 uppercase tracking-tighter leading-none">CodeBihin Verified</h3>
            <p class="text-slate-500 font-medium leading-relaxed mb-10 text-sm">
                This doctor profile has been manually verified by the <span class="text-blue-600 font-bold">CodeBihin Verification Hub</span>. We authenticate medical registration numbers, identity proofs, and physical chamber locations to ensure 100% trust.
            </p>
            <div class="flex items-center justify-center gap-3 text-emerald-600 font-black text-[10px] uppercase tracking-widest mb-10">
                <i class="fas fa-certificate text-lg"></i> Authenticated Medical Practitioner
            </div>
            <button onclick="toggleModal('verifyModal', false)" class="w-full py-5 rounded-3xl bg-slate-900 text-white font-black text-xs uppercase tracking-widest active:scale-95 transition-all">Close Window</button>
        </div>
    </div>

    <!-- PRIVACY POLICY MODAL -->
    <div id="privacyModal" class="hidden fixed inset-0 z-[5000] bg-slate-950/90 backdrop-blur-2xl flex items-center justify-center p-4">
        <div class="bg-white rounded-[60px] p-8 md:p-16 max-w-4xl w-full h-[85vh] relative shadow-3xl flex flex-col reveal-up">
            <button onclick="toggleModal('privacyModal', false)" class="absolute top-10 right-10 text-slate-400 hover:text-slate-900"><i class="fas fa-times text-2xl"></i></button>
            <h2 class="text-3xl md:text-5xl font-black mb-10 tracking-tighter uppercase border-b border-slate-100 pb-8">Privacy & Terms</h2>
            <div class="flex-1 overflow-y-auto custom-scrollbar pr-6 text-slate-600 text-sm md:text-base leading-relaxed space-y-8 font-medium">
                <section>
                    <h4 class="text-slate-900 font-black uppercase text-xs tracking-[0.3em] mb-4">1. We Care For Your Health</h4>
                    <p>At CodeBihin, patient data privacy is our cornerstone. We encrypt all medical interactions and ensure your health data remains sovereign to you. We do not sell data to pharmaceutical advertisers.</p>
                </section>
                <section>
                    <h4 class="text-slate-900 font-black uppercase text-xs tracking-[0.3em] mb-4">2. Verified Information Hub</h4>
                    <p>Every professional listed under our "Verified" status has undergone identity cross-checks. CodeBihin acts as a facilitator for healthcare discovery and scheduling.</p>
                </section>
                <section>
                    <h4 class="text-slate-900 font-black uppercase text-xs tracking-[0.3em] mb-4">3. Use of Services</h4>
                    <p>Users must provide accurate details while booking appointments. Any emergency should be handled by visiting the nearest hospital emergency room directly.</p>
                </section>
                <p class="text-[11px] text-slate-400 italic pt-10">Last Revised: Jan 2026. CodeBihin Compliance Cell.</p>
            </div>
            <button onclick="toggleModal('privacyModal', false)" class="mt-10 w-full py-6 rounded-3xl bg-blue-600 text-white font-black text-xs uppercase tracking-[0.4em]">Accept & Continue</button>
        </div>
    </div>

    <!-- MAIN NAVIGATION -->
    <nav class="fixed top-0 w-full z-[100] bg-white/90 backdrop-blur-xl border-b border-slate-100 h-16 md:h-24 flex items-center">
        <div class="container mx-auto px-4 md:px-10 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-4 group">
                <div class="w-12 h-12 md:w-16 md:h-16 bg-blue-600 rounded-[20px] flex items-center justify-center text-white shadow-2xl group-hover:rotate-12 transition-all duration-500">
                    <i class="fas fa-heart-pulse text-2xl md:text-3xl"></i>
                </div>
                <div class="flex flex-col">
                    <span class="text-2xl md:text-3xl font-black tracking-tighter text-slate-900 leading-none uppercase">CodeBihin</span>
                    <span class="text-[10px] md:text-[11px] font-bold text-emerald-500 uppercase tracking-widest mt-1 italic">We Care For Your Health</span>
                </div>
            </a>

            <!-- Desktop Nav -->
            <div class="hidden lg:flex items-center gap-10 font-black text-slate-600 text-[11px] uppercase tracking-[0.2em]">
                <a href="#home" class="hover:text-blue-600 transition-all">Home Hub</a>
                <a href="#specialties" class="hover:text-blue-600 transition-all">Browse Fields</a>
                <a href="#doctors" class="hover:text-blue-600 transition-all">Experts</a>
                <button onclick="toggleModal('privacyModal', true)" class="hover:text-blue-600 transition-all">Privacy Policy</button>
                <?php if(isUserLoggedIn()): ?>
                    <a href="dashboard.php" class="px-8 py-4 rounded-2xl bg-slate-900 text-white shadow-xl hover:bg-blue-600 transition-all active:scale-95">My Dashboard</a>
                <?php else: ?>
                    <button onclick="toggleModal('loginModal', true)" class="hover:text-blue-600 transition-all">Login</button>
                    <button onclick="toggleModal('regModal', true)" class="px-8 py-4 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/20 active:scale-95 transition-all">Join CodeBihin</button>
                <?php endif; ?>
            </div>

            <button onclick="toggleMobileMenu(true)" class="lg:hidden p-3 text-slate-600 bg-slate-50 rounded-2xl hover:bg-blue-50 transition-all"><i class="fas fa-bars-staggered text-xl"></i></button>
        </div>
    </nav>

    <!-- MOBILE SIDEBAR -->
    <div id="mobileMenu" class="fixed inset-0 z-[500] bg-white hidden flex flex-col p-10 transition-all duration-500">
        <div class="flex justify-between items-center mb-20">
            <span class="text-3xl font-black tracking-tighter text-slate-900 uppercase">CodeBihin</span>
            <button onclick="toggleMobileMenu(false)" class="p-4 text-slate-400 bg-slate-50 rounded-full"><i class="fas fa-times text-2xl"></i></button>
        </div>
        <div class="flex flex-col gap-12 text-3xl font-black text-slate-900 uppercase tracking-tighter">
            <a href="#home" onclick="toggleMobileMenu(false)">Health Home</a>
            <a href="#specialties" onclick="toggleMobileMenu(false)">Browse Specialties</a>
            <a href="#doctors" onclick="toggleMobileMenu(false)">Expert Doctors</a>
            <button onclick="toggleModal('privacyModal', true); toggleMobileMenu(false);" class="text-left">Privacy Policy</button>
        </div>
        <div class="mt-auto space-y-4">
            <button onclick="toggleModal('loginModal', true); toggleMobileMenu(false);" class="w-full py-6 rounded-3xl bg-slate-100 text-slate-900 font-bold uppercase tracking-widest text-[11px]">Sign In</button>
            <button onclick="toggleModal('regModal', true); toggleMobileMenu(false);" class="w-full py-6 rounded-3xl bg-blue-600 text-white font-black uppercase tracking-widest text-[11px]">Create Account</button>
        </div>
    </div>

    <!-- HERO SECTION -->
    <header id="home" class="pt-32 pb-24 md:pt-64 md:pb-48 medical-gradient relative overflow-hidden">
        <div class="absolute top-0 right-0 p-24 opacity-5 pointer-events-none animate-float">
            <i class="fas fa-hospital-user text-[500px]"></i>
        </div>
        <div class="container mx-auto px-6 text-center flex flex-col items-center relative z-10">
            <div class="inline-flex items-center gap-4 px-6 py-3 rounded-full bg-white border border-blue-100 text-blue-600 text-[10px] md:text-xs font-black mb-12 shadow-sm tracking-[0.3em] uppercase">
                <span class="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Official Healthcare Hub West Bengal
            </div>
            <h1 class="hero-title text-4xl md:text-8xl font-black text-slate-900 mb-10 leading-[1.05] tracking-tighter max-w-6xl reveal-up">
                Because We Care <br/> For Your <span class="text-blue-600 italic">Health.</span>
            </h1>
            <p class="text-slate-500 text-lg md:text-2xl mb-20 max-w-4xl font-medium leading-relaxed px-4 opacity-0 reveal-up" style="animation-delay: 0.2s">
                The most trusted digital health ecosystem for <span class="text-slate-900 font-bold">Tarakeswar</span> and <span class="text-slate-900 font-bold">Champadanga</span>. Find, book, and consult verified medical experts instantly.
            </p>
            
            <!-- SEARCH ENGINE -->
            <div class="hero-box w-full max-w-5xl bg-white p-4 md:p-6 rounded-[50px] shadow-[0_60px_120px_-30px_rgba(0,0,0,0.12)] flex flex-col md:flex-row gap-4 border border-blue-50/50 opacity-0 reveal-up" style="animation-delay: 0.4s">
                <div class="flex-1 flex items-center gap-5 px-10 py-6 bg-slate-50 rounded-[40px] border border-slate-100 transition-all focus-within:bg-white focus-within:border-blue-300">
                    <i class="fas fa-search text-blue-500 text-lg"></i>
                    <input type="text" placeholder="Cardiologist, Eye Specialist..." class="w-full bg-transparent outline-none font-bold text-slate-900 text-base">
                </div>
                <div class="flex-1 flex items-center gap-5 px-10 py-6 bg-slate-50 rounded-[40px] border border-slate-100 transition-all focus-within:bg-white focus-within:border-blue-300">
                    <i class="fas fa-map-marker-alt text-emerald-500 text-lg"></i>
                    <select id="locSearch" class="w-full bg-transparent outline-none font-bold text-slate-900 text-base cursor-pointer appearance-none">
                        <option value="all">Tarakeswar & Champadanga</option>
                        <option value="Tarakeswar">Tarakeswar Region</option>
                        <option value="Champadanga">Champadanga Area</option>
                    </select>
                </div>
                <button class="px-14 py-6 bg-blue-600 text-white rounded-[40px] font-black uppercase text-xs tracking-[0.25em] shadow-2xl shadow-blue-600/30 hover:bg-blue-700 hover:-translate-y-1 transition-all active:scale-95 shrink-0">Find Pro</button>
            </div>
        </div>
    </header>

    <!-- TRUST STRIP -->
    <section class="py-12 bg-white border-y border-slate-50">
        <div class="container mx-auto px-6">
            <div class="flex flex-wrap items-center justify-center gap-10 md:gap-24 opacity-40 grayscale hover:grayscale-0 transition-all duration-700">
                <div class="flex items-center gap-3 font-black text-slate-900 uppercase text-xs tracking-widest"><i class="fas fa-shield-alt text-xl"></i> Secured Portal</div>
                <div class="flex items-center gap-3 font-black text-slate-900 uppercase text-xs tracking-widest"><i class="fas fa-user-md text-xl"></i> Verified Hub</div>
                <div class="flex items-center gap-3 font-black text-slate-900 uppercase text-xs tracking-widest"><i class="fas fa-clock text-xl"></i> 24/7 Access</div>
                <div class="flex items-center gap-3 font-black text-slate-900 uppercase text-xs tracking-widest"><i class="fas fa-bolt text-xl"></i> Instant Booking</div>
            </div>
        </div>
    </section>

    <!-- SPECIALTIES SHOWCASE -->
    <section id="specialties" class="py-24 md:py-48 bg-white">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row items-center justify-between mb-32 gap-10 text-center md:text-left">
                <div>
                    <h2 class="text-4xl md:text-7xl font-black text-slate-900 mb-6 tracking-tighter uppercase leading-none">Browse Specialties</h2>
                    <p class="text-slate-400 font-bold uppercase text-[12px] tracking-[0.4em]">Comprehensive healthcare network in your area</p>
                </div>
                <button class="px-12 py-6 rounded-full bg-slate-50 text-blue-600 font-black text-xs uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all shadow-sm">View All 30+ Fields</button>
            </div>
            
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 md:gap-10">
                <?php
                $fields = [
                    ['n' => 'Physician', 'i' => 'fa-user-doctor', 'c' => 'blue', 'q' => 28],
                    ['n' => 'Cardiology', 'i' => 'fa-heart-pulse', 'c' => 'red', 'q' => 14],
                    ['n' => 'Pediatrics', 'i' => 'fa-baby', 'c' => 'emerald', 'q' => 22],
                    ['n' => 'Dentistry', 'i' => 'fa-tooth', 'c' => 'sky', 'q' => 25],
                    ['n' => 'Orthopedics', 'i' => 'fa-bone', 'c' => 'orange', 'q' => 19],
                    ['n' => 'Neurology', 'i' => 'fa-brain', 'c' => 'purple', 'q' => 11],
                    ['n' => 'Ophthalmology', 'i' => 'fa-eye', 'c' => 'pink', 'q' => 15],
                    ['n' => 'Dermatology', 'i' => 'fa-allergies', 'c' => 'amber', 'q' => 18],
                    ['n' => 'Gynecology', 'i' => 'fa-venus', 'c' => 'rose', 'q' => 21],
                    ['n' => 'ENT Spcl.', 'i' => 'fa-ear-listen', 'c' => 'indigo', 'q' => 10],
                    ['n' => 'Urology', 'i' => 'fa-vial', 'c' => 'cyan', 'q' => 8],
                    ['n' => 'Pathology', 'i' => 'fa-microscope', 'c' => 'slate', 'q' => 32],
                ];
                foreach($fields as $f): ?>
                <div class="group bg-white p-12 rounded-[60px] border border-slate-100 text-center hover:shadow-2xl hover:border-blue-100 transition-all duration-500 cursor-pointer relative overflow-hidden">
                    <div class="w-16 h-16 md:w-20 md:h-20 bg-<?php echo $f['c']; ?>-50 text-<?php echo $f['c']; ?>-600 rounded-[35px] flex items-center justify-center text-3xl md:text-4xl mb-8 mx-auto group-hover:scale-110 group-hover:rotate-12 transition-all duration-700">
                        <i class="fas <?php echo $f['i']; ?>"></i>
                    </div>
                    <h3 class="font-black text-slate-900 text-[14px] md:text-base mb-2 uppercase tracking-tight"><?php echo $f['n']; ?></h3>
                    <p class="text-[10px] font-black uppercase text-slate-300 tracking-[0.2em]"><?php echo $f['q']; ?> Doctors</p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- EXPERT DOCTORS SECTION -->
    <section id="doctors" class="py-24 md:py-48 bg-slate-50 section-curve relative overflow-hidden">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row items-center justify-between mb-32 gap-10 text-center md:text-left">
                <div>
                    <h2 class="text-4xl md:text-7xl font-black text-slate-900 mb-6 tracking-tighter uppercase leading-none">Expert Doctors</h2>
                    <p class="text-slate-400 font-bold uppercase text-[12px] tracking-[0.4em]">Hand-picked and verified healthcare professionals</p>
                </div>
                <div class="flex p-2.5 bg-white rounded-[40px] border border-slate-100 shadow-sm">
                    <button id="btn-all" onclick="filterDoctors('all')" class="px-10 py-4 rounded-[32px] text-[11px] font-black uppercase tracking-widest transition-all bg-slate-900 text-white shadow-2xl">All Areas</button>
                    <button id="btn-tar" onclick="filterDoctors('Tarakeswar')" class="px-10 py-4 rounded-[32px] text-[11px] font-black uppercase tracking-widest transition-all text-slate-400 hover:bg-slate-50">Tarakeswar</button>
                    <button id="btn-cha" onclick="filterDoctors('Champadanga')" class="px-10 py-4 rounded-[32px] text-[11px] font-black uppercase tracking-widest transition-all text-slate-400 hover:bg-slate-50">Champadanga</button>
                </div>
            </div>
            
            <div id="doctorGrid" class="doc-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 md:gap-16">
                <?php
                $docs = [
                    ['n' => 'Dr. Amit Sharma', 's' => 'Senior Cardiologist', 'r' => 4.9, 'l' => 'Tarakeswar', 'x' => '15+ Years', 'a' => '👨‍⚕️'],
                    ['n' => 'Dr. Priya Patel', 's' => 'Dermatology Expert', 'r' => 4.8, 'l' => 'Champadanga', 'x' => '12+ Years', 'a' => '👩‍⚕️'],
                    ['n' => 'Dr. Rajesh Kumar', 's' => 'Orthopedic Surgeon', 'r' => 4.7, 'l' => 'Tarakeswar', 'x' => '18+ Years', 'a' => '👨‍⚕️'],
                    ['n' => 'Dr. Sunita Sen', 's' => 'Pediatrics Spcl.', 'r' => 4.9, 'l' => 'Champadanga', 'x' => '10+ Years', 'a' => '👩‍⚕️'],
                    ['n' => 'Dr. Binay Ghosh', 's' => 'General Physician', 'r' => 4.6, 'l' => 'Tarakeswar', 'x' => '20+ Years', 'a' => '👨‍⚕️'],
                    ['n' => 'Dr. Moushumi Dey', 's' => 'Sr. Gynecologist', 'r' => 4.8, 'l' => 'Champadanga', 'x' => '14+ Years', 'a' => '👩‍⚕️'],
                ];
                foreach($docs as $doc): ?>
                <div class="doc-card group bg-white rounded-[70px] border border-slate-100 p-10 md:p-14 hover:shadow-3xl transition-all duration-700 relative overflow-hidden" data-loc="<?php echo $doc['l']; ?>">
                    <div class="doc-header-mobile flex items-start gap-10 mb-14">
                        <div class="doc-avatar-mobile w-28 h-28 md:w-32 md:h-32 bg-blue-50 text-blue-600 rounded-[50px] flex items-center justify-center text-5xl md:text-6xl group-hover:rotate-6 transition-all duration-700 shrink-0 shadow-inner">
                            <?php echo $doc['a']; ?>
                        </div>
                        <div class="flex-1">
                            <h3 class="font-black text-slate-900 text-2xl md:text-4xl uppercase tracking-tighter leading-[0.85] mb-4">
                                <?php echo $doc['n']; ?>
                                <span class="blue-tick-verify" onclick="toggleModal('verifyModal', true)" title="Verified Profile: See Details"><i class="fas fa-check"></i></span>
                            </h3>
                            <p class="text-blue-600 font-bold text-[11px] md:text-[12px] uppercase tracking-[0.25em] mb-4 leading-none"><?php echo $doc['s']; ?></p>
                            <div class="flex items-center justify-center md:justify-start gap-2.5 font-black text-[12px]">
                                <span class="text-yellow-400"><i class="fas fa-star"></i></span>
                                <span class="text-slate-900"><?php echo $doc['r']; ?></span>
                                <span class="text-slate-300 ml-1 font-bold">(150+ Reviews)</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-12 text-center">
                        <div class="cb-verified-stamp reveal-stamp">
                            <i class="fas fa-check-circle mr-2 text-blue-600"></i> DOCTOR PROFILE VERIFIED BY CODEBIHIN
                        </div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-5 opacity-50">Profile Authentication ID: CB-DOC-<?php echo rand(1000, 9999); ?></p>
                    </div>

                    <div class="grid grid-cols-2 gap-5 mb-14">
                        <div class="p-8 bg-slate-50 rounded-[40px] border border-slate-100 text-center hover:bg-white transition-all">
                            <p class="text-[9px] text-slate-400 font-black uppercase mb-3 tracking-[0.2em]">Experience</p>
                            <p class="font-black text-slate-900 text-[14px] md:text-[16px] tracking-tight uppercase"><?php echo $doc['x']; ?></p>
                        </div>
                        <div class="p-8 bg-slate-50 rounded-[40px] border border-slate-100 text-center hover:bg-white transition-all">
                            <p class="text-[9px] text-slate-400 font-black uppercase mb-3 tracking-[0.2em]">Chamber Address</p>
                            <p class="font-black text-slate-900 text-[14px] md:text-[16px] tracking-tight uppercase"><?php echo $doc['l']; ?></p>
                        </div>
                    </div>
                    <button class="w-full py-7 rounded-[40px] bg-slate-900 text-white font-black text-[12px] uppercase tracking-[0.4em] hover:bg-blue-600 transition-all shadow-2xl shadow-slate-900/10 active:scale-95">Book Appointment</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- TESTIMONIALS SYSTEM -->
    <section class="py-24 md:py-48 bg-white relative">
        <div class="container mx-auto px-6">
            <div class="text-center mb-32">
                <h2 class="text-4xl md:text-8xl font-black text-slate-900 mb-8 tracking-tighter uppercase leading-none">Patient Voices</h2>
                <p class="text-slate-400 font-bold uppercase text-[12px] tracking-[0.5em]">Real experiences from our local community</p>
            </div>
            
            <div id="reviewSlider" class="cb-slider pb-12">
                <?php
                $testimonials = [
                    ['n' => 'Ankit Roy', 'l' => 'Tarakeswar', 't' => "Found a cardiology expert instantly for my father. The verified blue tick gives me total confidence. Highly professional portal!"],
                    ['n' => 'Suman Mal', 'l' => 'Champadanga', 't' => "CodeBihin is a game-changer. The chamber addresses are accurate and the booking process is seamless. Best for regional patients."],
                    ['n' => 'Sneha Das', 'l' => 'Tarakeswar', 't' => "Finally a medical hub that really cares. The digital verification stamp makes it feel secure and official. 10/10 recommend."],
                    ['n' => 'Priya Biswas', 'l' => 'Haripal', 't' => "I always check CodeBihin before visiting any clinic now. The reviews are authentic and the UI is incredibly easy to use."],
                    ['n' => 'Mukul Sen', 'l' => 'Champadanga', 't' => "Truly 'We Care For Your Health' is lived here. Zero patient fee and verified doctors only. A blessing for our area."],
                    ['n' => 'Rita Ghosh', 'l' => 'Tarakeswar', 't' => "Fast, reliable, and verified. Team CodeBihin has built something truly special for our regional healthcare needs."]
                ];
                foreach($testimonials as $rev): ?>
                <div class="cb-slide px-5">
                    <div class="p-14 rounded-[70px] bg-slate-50 border border-slate-100 hover:bg-blue-50/40 transition-all duration-700 h-full flex flex-col group">
                        <div class="flex gap-1.5 text-yellow-400 mb-10 group-hover:scale-110 transition-all"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                        <p class="text-slate-600 text-xl md:text-2xl font-medium leading-relaxed mb-12 italic flex-1">"<?php echo $rev['t']; ?>"</p>
                        <div class="flex items-center gap-6 pt-10 border-t border-slate-200 mt-auto">
                            <div class="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white font-black text-2xl shadow-xl"><?php echo substr($rev['n'], 0, 1); ?></div>
                            <div>
                                <h4 class="font-black text-slate-900 uppercase text-sm mb-1"><?php echo $rev['n']; ?></h4>
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><?php echo $rev['l']; ?> • Verified Resident</p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="flex justify-center gap-6 mt-12">
                <button onclick="prevSlide()" class="w-16 h-16 rounded-full border border-slate-200 flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all shadow-sm active:scale-90"><i class="fas fa-chevron-left text-lg"></i></button>
                <button onclick="nextSlide()" class="w-16 h-16 rounded-full border border-slate-200 flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all shadow-sm active:scale-90"><i class="fas fa-chevron-right text-lg"></i></button>
            </div>
        </div>
    </section>

    <!-- FOOTER SYSTEM -->
    <footer class="bg-[#020617] pt-32 pb-16 px-6 md:px-12 border-t border-white/5">
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-20 mb-32 text-center md:text-left">
                <div class="col-span-1 md:col-span-1">
                    <div class="flex items-center justify-center md:justify-start gap-5 mb-12">
                        <div class="w-16 h-16 bg-blue-600 rounded-[24px] flex items-center justify-center text-white font-black text-3xl shadow-3xl">C</div>
                        <span class="text-4xl font-black tracking-tighter text-white uppercase leading-none">CodeBihin</span>
                    </div>
                    <p class="text-slate-500 font-bold text-xs leading-relaxed mb-12 uppercase tracking-[0.2em]">Dedicated to simplifying healthcare access for Tarakeswar and Champadanga. We care for your health.</p>
                    <div class="flex justify-center md:justify-start gap-8">
                        <a href="mailto:admin@codebihin.in" class="text-slate-500 hover:text-blue-500 transition-all text-2xl"><i class="fas fa-envelope"></i></a>
                        <a href="mailto:support@codebihin.in" class="text-slate-500 hover:text-blue-500 transition-all text-2xl"><i class="fas fa-headset"></i></a>
                        <a href="#" class="text-slate-500 hover:text-blue-500 transition-all text-2xl"><i class="fab fa-facebook-f"></i></a>
                    </div>
                </div>
                
                <div>
                    <h4 class="text-white font-black uppercase text-[11px] tracking-[0.7em] mb-16 opacity-30">Quick Access</h4>
                    <ul class="space-y-7 text-slate-400 font-black text-xs uppercase tracking-[0.25em]">
                        <li><a href="#home" class="hover:text-blue-500 transition-all">Health Portal Home</a></li>
                        <li><a href="#specialties" class="hover:text-blue-500 transition-all">Verified Specialties</a></li>
                        <li><a href="#doctors" class="hover:text-blue-500 transition-all">Expert Doctors</a></li>
                        <li><button onclick="toggleModal('privacyModal', true)" class="hover:text-blue-500 transition-all">Privacy Policy</button></li>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-black uppercase text-[11px] tracking-[0.7em] mb-16 opacity-30">Our Ecosystem</h4>
                    <ul class="space-y-7 text-slate-400 font-black text-xs uppercase tracking-[0.25em]">
                        <li><a href="#" class="hover:text-blue-500 transition-all">Doctor Registration</a></li>
                        <li><a href="#" class="hover:text-blue-500 transition-all">Chamber Hubs</a></li>
                        <li><a href="#" class="hover:text-blue-500 transition-all">Regional Centers</a></li>
                        <li><button onclick="toggleModal('privacyModal', true)" class="hover:text-blue-500 transition-all text-left">Terms of Use</button></li>
                    </ul>
                </div>

                <div class="p-12 glass-card rounded-[60px] flex flex-col items-center md:items-start relative overflow-hidden">
                    <h4 class="text-slate-900 font-black text-sm uppercase tracking-widest mb-6">Patient Support</h4>
                    <p class="text-slate-500 text-[10px] font-bold uppercase mb-12 text-center md:text-left tracking-[0.25em] leading-relaxed">Dedicated regional support desk available for all appointment queries.</p>
                    <div class="flex flex-col gap-4 w-full">
                        <a href="mailto:support@codebihin.in" class="px-10 py-6 rounded-3xl bg-blue-600 text-white font-black text-[11px] uppercase tracking-[0.35em] shadow-2xl shadow-blue-600/20 active:scale-95 transition-all text-center">Support Desk</a>
                        <a href="mailto:admin@codebihin.in" class="text-slate-900 font-black text-[11px] uppercase tracking-[0.35em] opacity-50 hover:opacity-100 transition-all text-center mt-4">admin@codebihin.in</a>
                    </div>
                </div>
            </div>

            <div class="pt-20 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-10 text-[10px] font-black uppercase tracking-[0.6em] text-slate-800">
                <p>© <?php echo date('Y'); ?> CodeBihin Healthcare Systems. Build with Pride in India.</p>
                <div class="flex flex-wrap justify-center gap-12">
                    <span class="text-emerald-500"><i class="fas fa-heart-pulse mr-2"></i> We Care For Your Health</span>
                    <span class="text-blue-500 hover:underline cursor-pointer" onclick="toggleModal('privacyModal', true)">Compliance Cell</span>
                </div>
            </div>
        </div>
    </footer>

    <!-- MODAL SYSTEMS (LOGIN/REG) -->
    <div id="loginModal" class="hidden fixed inset-0 z-[6000] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4">
        <div class="bg-white rounded-[70px] p-12 md:p-24 max-w-md w-full relative shadow-3xl text-center reveal-up">
            <button onclick="toggleModal('loginModal', false)" class="absolute top-12 right-12 text-slate-300 hover:text-slate-900"><i class="fas fa-times text-3xl"></i></button>
            <h2 class="text-4xl font-black mb-16 tracking-tighter uppercase leading-none text-slate-900">Sign In</h2>
            <form action="login_process.php" method="POST" class="space-y-8 text-left">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Email Address</label>
                    <input type="email" name="e" required class="w-full px-10 py-6 rounded-3xl bg-slate-50 border border-slate-100 focus:border-blue-500 outline-none font-bold text-base transition-all">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Password</label>
                    <input type="password" name="p" required class="w-full px-10 py-6 rounded-3xl bg-slate-50 border border-slate-100 focus:border-blue-500 outline-none font-bold text-base transition-all">
                </div>
                <button type="submit" class="w-full py-7 rounded-3xl bg-blue-600 text-white font-black text-xs uppercase tracking-[0.4em] shadow-2xl active:scale-95 transition-all">Enter Portal</button>
            </form>
            <p class="mt-12 text-slate-400 font-bold text-[10px] uppercase tracking-widest">Don't have an account? <button onclick="toggleModal('loginModal', false); toggleModal('regModal', true);" class="text-blue-600 hover:underline">Join Now</button></p>
        </div>
    </div>

    <div id="regModal" class="hidden fixed inset-0 z-[6000] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4">
        <div class="bg-white rounded-[70px] p-12 md:p-20 max-w-xl w-full relative shadow-3xl reveal-up">
            <button onclick="toggleModal('regModal', false)" class="absolute top-12 right-12 text-slate-300 hover:text-slate-900"><i class="fas fa-times text-3xl"></i></button>
            <h2 class="text-4xl md:text-5xl font-black mb-16 tracking-tighter text-center uppercase leading-[0.9] text-slate-900">Join Our <br/> Health Hub</h2>
            <div class="flex flex-col gap-6">
                <button onclick="window.location.href='register.php?role=patient'" class="flex flex-col md:flex-row items-center gap-10 p-12 rounded-[50px] border border-slate-100 hover:border-blue-200 hover:bg-blue-50/40 transition-all text-center md:text-left group">
                    <div class="w-20 h-20 bg-blue-100 rounded-[30px] flex items-center justify-center text-5xl group-hover:scale-110 transition-all shrink-0 text-blue-600">🤒</div>
                    <div>
                        <h4 class="font-black text-slate-900 uppercase text-sm mb-2 tracking-tight">Patient Account</h4>
                        <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest leading-relaxed">Book appointments and consult experts instantly.</p>
                    </div>
                </button>
                <button onclick="window.location.href='register.php?role=doctor'" class="flex flex-col md:flex-row items-center gap-10 p-12 rounded-[50px] border border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/40 transition-all text-center md:text-left group">
                    <div class="w-20 h-20 bg-emerald-100 rounded-[30px] flex items-center justify-center text-5xl group-hover:scale-110 transition-all shrink-0 text-emerald-600">👨‍⚕️</div>
                    <div>
                        <h4 class="font-black text-slate-900 uppercase text-sm mb-2 tracking-tight">Medical Expert</h4>
                        <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest leading-relaxed">Join our verified network and manage your chamber.</p>
                    </div>
                </button>
            </div>
        </div>
    </div>

    <!-- SCRIPT INFRASTRUCTURE -->
    <script>
        // Back to top button logic
        let btt = document.getElementById("bttBtn");
        window.onscroll = function() { scrollHandler() };

        function scrollHandler() {
            if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
                btt.classList.add("active");
            } else {
                btt.classList.remove("active");
            }
        }

        function scrollToTop() {
            window.scrollTo({top: 0, behavior: 'smooth'});
        }

        // Overlay & Modal Controllers
        function closeBuildingOverlay() {
            const overlay = document.getElementById('buildingOverlay');
            if(overlay) overlay.style.display = 'none';
        }

        function toggleMobileMenu(show) {
            const m = document.getElementById('mobileMenu');
            m.classList.toggle('hidden', !show);
            document.body.style.overflow = show ? 'hidden' : 'auto';
        }

        function toggleModal(id, show) {
            const el = document.getElementById(id);
            if(el) {
                el.classList.toggle('hidden', !show);
                document.body.style.overflow = show ? 'hidden' : 'auto';
            }
        }

        // Testimonial Slider Controllers
        function nextSlide() {
            const slider = document.getElementById('reviewSlider');
            const scrollWidth = slider.offsetWidth;
            if (slider.scrollLeft + scrollWidth >= slider.scrollWidth) {
                slider.scrollTo({left: 0, behavior: 'smooth'});
            } else {
                slider.scrollBy({left: scrollWidth, behavior: 'smooth'});
            }
        }

        function prevSlide() {
            const slider = document.getElementById('reviewSlider');
            const scrollWidth = slider.offsetWidth;
            slider.scrollBy({left: -scrollWidth, behavior: 'smooth'});
        }

        // Doctor Filtering Logic
        function filterDoctors(loc) {
            const cards = document.querySelectorAll('.doc-card');
            const btns = { all: 'btn-all', tar: 'btn-tar', cha: 'btn-cha' };
            
            // Reset Buttons
            Object.values(btns).forEach(id => {
                const btn = document.getElementById(id);
                if(btn) btn.className = "px-10 py-4 rounded-[32px] text-[11px] font-black uppercase tracking-widest transition-all text-slate-400 hover:bg-slate-50";
            });

            // Active Button
            const activeId = loc === 'all' ? btns.all : (loc === 'Tarakeswar' ? btns.tar : btns.cha);
            const activeBtn = document.getElementById(activeId);
            if(activeBtn) activeBtn.className = "px-10 py-4 rounded-[32px] text-[11px] font-black uppercase tracking-widest transition-all bg-slate-900 text-white shadow-2xl";
            
            // Filter Cards
            cards.forEach(card => {
                if(loc === 'all' || card.getAttribute('data-loc') === loc) {
                    card.style.display = 'block';
                    card.classList.add('reveal-up');
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Auto-Initialize
        document.addEventListener('DOMContentLoaded', () => {
            filterDoctors('all');
            
            // Slow Reveal for Digital Stamps
            setTimeout(() => {
                document.querySelectorAll('.cb-verified-stamp').forEach(stamp => {
                    stamp.classList.add('reveal-stamp');
                });
            }, 1200);

            // Auto-Slide Reviews every 7 seconds
            setInterval(nextSlide, 7000);
        });
    </script>
</body>
</html>